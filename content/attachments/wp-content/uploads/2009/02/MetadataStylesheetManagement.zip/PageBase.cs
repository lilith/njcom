using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Diagnostics;
using System.Text.RegularExpressions;
using System.Collections.Specialized;

namespace fbs
{

    /// <summary>
    /// Extends System.Web.UI.Page
    /// Adds metadata and stylehseet management
    /// </summary>
    public partial class PageBase : Page
    {
        /// <summary>
        /// Creates a new PageBase instance. 
        /// </summary>
        public PageBase()
        {
        }


        protected MetadataManager _metadata = null;
        /// <summary>
        /// Manages page metadata. Add, remove, and query metadata 
        /// (Only meta tags with a name attribute are affected, and only those located in the head section)
        /// </summary>
        public MetadataManager Metadata { 
            get {
                if (_metadata == null) _metadata = new MetadataManager(this);
                return _metadata; 
            } 
        }


        protected LinkManager _Stylesheets = null;
        /// <summary>
        /// Manages all of the HtmlLink controls in the head section of the page.
        /// Register, delete, and enumerate all link tags.
        /// </summary>
        public LinkManager Stylesheets
        {
            get
            {
                if (_Stylesheets == null) _Stylesheets = new LinkManager(this);
                return _Stylesheets;
            }
        }


         /// <summary>
        /// Iterates over the control structure of the specified object and returns all elements that are
        /// of the specified type
        /// </summary>
        /// <param name="parent"></param>
        /// <returns></returns>
        public static List<T> GetControlsOfType<T>(Control parent) where T : Control
        {
            return GetControlsOfType<T>(parent, false,false);
        }
        /// <summary>
        /// Iterates over the control structure of the specified object and returns all elements that are
        /// of the specified type. If there are two items of the specified type, and one is a child of the other, 
        /// the childrenOnly and parentOnly parameters can be used to control which is selected. If both are false, both controls are returned.
        /// </summary>
        /// <param name="parent">The control to search</param>
        /// <param name="childrenOnly">If true, only the innermost matching children will be returned.</param>
        /// <param name="parentsOnly">If true, only the outermost matching parents will be returned.</param>
        /// <returns></returns>
        public static List<T> GetControlsOfType<T>(Control parent, bool childrenOnly, bool parentsOnly) where T : Control
        {
            if (parent == null) return null;
            if (childrenOnly && parentsOnly) throw 
                new ArgumentException("Only one of childrenOnly and parentsOnly may be true. They are mutually exclusive");

            //We are doing last-minute initialization to minimize the overhead of building one of these.
            //The List<> constructor should only be called n times, where n is the number of ContentPlaceHolder controls.
            List<T> temp = null;

            if (parent.Controls != null)
            {
                //Loop through all of the child controls
                foreach (Control child in parent.Controls)
                {
                    //Recursively search them also.
                    List<T> next = GetControlsOfType<T>(child,childrenOnly,parentsOnly);

                    //To save on initialization costs.
                    if (next != null)
                    {
                        if (temp == null)
                        {
                            temp = next; //Use existing collection from recursive call
                        }
                        else
                        {
                            //Merge the collections

                            //If a the same object is the child of two different parents, this will
                            //stop it.
                            foreach (T c in next)
                            {
                                if (!temp.Contains(c)) temp.Add(c);
                            }

                        }
                    }
                }
            }

            //If this item is of the target type, add it 
            if ((parent is T))
            {
                //If there are no children or we are trying to discard children
                if (parentsOnly || temp == null)
                {
                    //Clear the list and add the parent
                    T item = (T)parent;

                    temp = new List<T>();

                    temp.Add(item);
                }
                else if (!childrenOnly)
                {
                    //Append the parent with the children
                    T item = (T)parent;

                    if (temp == null) temp = new List<T>();

                    temp.Add(item);
                }
            }

            return temp;
        }
    }
}